CECS 326 Project 3 Application for Threads Sorting

November 8, 2020

Students:ID
- Donovan Lee   : 016741645
- Min Kyaw      : 018182136

How To Run Code:
    1. Unzip the package and save it to your desired location 
    2. Make sure that you are using a Linux OS to run this program
    3. Open up terminal
    4. Go to where you saved the file by doing:
        cd FileLocationPath
    5. When you get to the file's location there will be a make file that contains the compiling code:
        -gcc main.c -pthread -o main
    6. In the terminal type in the word:
        make
        - this will create the application to run
    7.If make does not work then install the make package(skip this step if make works):
        sudo apt install make  
8. In order to run the file type this into the command line:
    - ./main